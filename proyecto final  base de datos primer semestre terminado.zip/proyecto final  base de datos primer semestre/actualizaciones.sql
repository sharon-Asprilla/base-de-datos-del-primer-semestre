use Bienestar_Animal

insert into Usuario (nombre,apellido,telefono,direccion,correoelectronico,tipo_usuario,contrase�a)
values
('sara','zapata','31331313','cra50-#89-22','sarayaspril@hgail','reportante','1234'),
('sofia','correa','31029313','diagonal 32-#22-09','sofiacil@hgail','donante','12894'),
('oscar','escobar','3389021313','avda42-#24-19','oscarecb@hgail','reportante','0334'),
('luisa','restrepo','34251313','cra28-#56-99','sluires@hgail','adoptante','18494'),
('luis','lopera','31903723','avda90-#67-82','luislope@hgail','reportante','10398')

insert into Animal (especie,raza,edad_estimada,sexo,condicionfisica,ubicacion_actual,estado_adopcion)
values ('gato','europea','20','femenino','herido','cra27 #87-90','pendiente'),
('perro','golden','10','masculino','sin dos pies','cra56 #32-01','adoptado'),
('perro','pitbull','80','femenino','herido','cra87 #27-45','pendiente')


insert into Reportaje (fecha,descripcion,estado)
values ('2008-02-17','habitaba en las calles','atendido'),
 ('09-10-02','habitaba en las calles','atendido'),
 ('2025-08-24','habitaba en las calles','pendiente')

 insert into Atencion_veterinari(fecha,diagnostico,tratamiento,veterinario_responsable)
 values ('2025-09-30','invalido','terapias de movilidad','eduardo agudelo'),
 ('2025-06-19','rebote','pastilla para el vomito','natalia cordoba'),
 ('2024-12-30','da�o intenstinal','inyeccion','angie rios'),
 ('2025-12-01','gripe','inyeccion','eduardo agudelo')

 

 insert into Adopciones (fecha_solicitud,fecha_aprovacion,estado_adopcion)
 values ('2024-03-24','2024-03-28','adoptado'),
 ('2024-05-19','2024-05-20','adoptado'),
 ('2025-03-30','2025-03-10','adoptado')

 insert into donaciones (fecha,cantidad,tipo_donacion)
 values ('2020-06-11','16 ','alimento'),
 ('2020-11-18','10','alimento'),
 ('2020-09-08','107 ','alimento')

 --vamos a ser uhna consulta donde el apellido de un usuario termine en z

 select * from Usuario
 where apellido like '%z%'

 --vamos hacer una consulta donde nos muestre que nombres no estan nulos
 --en la base de datos
 select * from Usuario
 where nombre is not null

 --consultame la edad mayor de diez que se encuentre en la base de datos
 select * from Animal
 where edad_estimada > 10  


 --muestrame donde el nombre y el apellido incluya la c
 select * from Usuario
 where nombre like '%c%' and apellido  is not null

 --actualizacion de la edad del animal con el posicionamiento 3
UPDATE Animal
SET edad_estimada = 30
WHERE idAnimal = 3;

--ver tabla aniaml para ver los cambios
select * from Animal
--vamos a cambiar la contrase�a de la primera persona registrada
update Usuario
set contrase�a = 12679 
where idUsuario = 1;

--vemos la actualizacion
select * from Usuario
--aqui usamos el delete para poder borrar un dato
delete from  Atencion_veterinari
where idAtencion= 2;

--vemos ese dato borrado
select * from Atencion_veterinari
 

--una consulta donde me traiga la cantidad donada mayor a 50
select idusuario,cantidad
from donaciones  
where cantidad > 10;

--donaciones mayores de 10
SELECT * FROM donaciones WHERE cantidad > 10;

--para ver la union de dos tablas viendo la coincidencia de de izquierda
select * from donaciones d
LEFT JOIN Usuario u on d.idUsuario = u.idUsuario;

--para ver cuantos atendio el veterinario responsable
SELECT idAtencion, fecha, diagnostico, tratamiento 
FROM Atencion_Veterinari 
WHERE veterinario_responsable = 'Eduardo Agudelo';

--para contar cuantas adopcines fueron aprobadas
SELECT COUNT(*) AS total_adopciones_aprobadas 
FROM Adopciones 
WHERE estado_adopcion = 'adoptado';




--prodedimiento almacenado

--hice aqui la muestra de el total con suma pero imprimiendolo
--usando un (print)

CREATE PROCEDURE ObtenerTotalDonaciones
    @totalDonaciones INT OUTPUT
AS
BEGIN
    SELECT @totalDonaciones = SUM(cantidad) 
    FROM donaciones;
END;
GO
DECLARE @cantidadDonada INT;
EXEC ObtenerTotalDonaciones @cantidadDonada OUTPUT;
PRINT 'Se han recibido un total de ' + CAST(@cantidadDonada AS VARCHAR) + ' unidades de donaciones.';


-- aqui hice la suma de datos en tabla use el (select)

CREATE PROCEDURE ObtenerTotalDonacionessuma
    @totalDonacioness INT OUTPUT
AS
BEGIN
    SELECT @totalDonacioness = SUM(cantidad) 
    FROM donaciones;
END;
GO


DECLARE @cantidadDonada INT;
EXEC ObtenerTotalDonacionessuma @cantidadDonada OUTPUT;
select  'Se han recibido un total de ' + CAST(@cantidadDonada AS VARCHAR) + ' unidades de donaciones.';






