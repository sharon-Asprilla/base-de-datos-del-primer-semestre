CREATE DATABASE procedimientos_almacenados;
GO

USE procedimientos_almacenados;
GO

CREATE TABLE Categoria ( 
    idCategoria INT PRIMARY KEY IDENTITY(1,1), 
    nombre VARCHAR(100) 
);
GO

CREATE TABLE Comida ( 
    idComida INT PRIMARY KEY IDENTITY(1,1), 
    nombre VARCHAR(50), 
    idCategoria INT CONSTRAINT FK_IDcategoria FOREIGN KEY REFERENCES Categoria(idCategoria),
    precio REAL DEFAULT 0.00 
);
GO

CREATE PROCEDURE insertarComida
    @nombre VARCHAR(50), 
    @categoriaNombre VARCHAR(100), 
    @precio FLOAT
AS
BEGIN 
    DECLARE @idCategoria INT; 
    SET @idCategoria = (SELECT TOP 1 idCategoria FROM Categoria WHERE nombre = @categoriaNombre); 
 
    IF @idCategoria IS NULL 
    BEGIN 
        RAISERROR('La categor�a no existe', 16, 1); 
        RETURN;
    END 
    ELSE 
    BEGIN 
        INSERT INTO Comida (nombre, idCategoria, precio) VALUES (@nombre, @idCategoria, @precio); 
    END; 
END;
GO

-- Insertar una categor�a para probar
INSERT INTO Categoria (nombre) VALUES ('Comida R�pida');
GO

-- Ejecutar el procedimiento
EXEC insertarComida @nombre = 'Pizza', @categoriaNombre = 'Comida R�pida', @precio = 50.00;
GO

-- Verificar que se insert�
SELECT * FROM Comida;
GO

--verificar que se inserto pero con el nombre de la categoria--
SELECT 
    c.idComida,
    c.nombre AS NombreComida,
    cat.nombre AS NombreCategoria,
    c.precio
FROM 
    Comida c
INNER JOIN 
    Categoria cat ON c.idCategoria = cat.idCategoria;


	EXEC insertarComida @nombre = 'Hamburgesa', @categoriaNombre = 'Comida R�pida', @precio = 60.00;

