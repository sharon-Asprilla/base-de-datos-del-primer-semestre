create database Bienestar_Animal
use Bienestar_Animal

create table Usuario (
idUsuario int  primary key identity (1,1),
nombre varchar (50) not null,
apellido varchar (50),
telefono varchar (50),
direccion varchar (50),
correoelectronico varchar (50) unique,
tipo_usuario varchar (50),
contrase�a varchar (10) unique
)

create table Animal (
idAnimal  int primary key identity(1,1),
especie varchar (50),
raza varchar (50),
edad_estimada varchar (10),
sexo varchar (40),
condicionfisica varchar (50),
ubicacion_actual varchar (50)not null,
estado_adopcion varchar (50)
)

create table Reportaje (
idReportaje int primary key identity (1,1),
idUsuario int,
idAnimal int,
fecha date,
descripcion varchar (100),
estado varchar (50) not null,
constraint fk_idUsuario foreign key (idUsuario)references Usuario (idUsuario),
constraint fk_idAnimal foreign key (idAnimal) references Animal (idAnimal)
)

create table Atencion_Veterinari (
idAtencion int primary key identity (1,1),
idAnimal int,
fecha date,
diagnostico varchar (100)not null,
tratamiento varchar (100),
veterinario_responsable varchar (100),
constraint Fk_idAnimal_Atenciones foreign key (idAnimal) references Animal (idAnimal)
)

create table Adopciones (
idAdopciones int primary key identity (1,1),
idAnimal int,
idUsuario int,
fecha_solicitud date,
fecha_aprovacion date,
estado_adopcion varchar (100),
constraint fk_idUsuarios_Adopciones foreign key (idUsuario)references Usuario(idUsuario),
constraint fk_idAnimales_Adopciones foreign key (idAnimal) references Animal (idAnimal)
)

create table donaciones (
id_donaciones int primary key identity (1,1),
idUsuario int,
fecha date,
cantidad int,
tipo_donacion varchar (100),
constraint fk_idUsuario_donaciones foreign key (idUsuario) references Usuario (idUsuario)
)

